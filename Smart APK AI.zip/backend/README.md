# Backend - FastAPI Chat Core

## Setup
```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

The server runs at http://localhost:8000 and exposes `/chat`.
