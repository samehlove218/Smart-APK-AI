async function previewApp() {
    const desc = document.getElementById('description').value;
    const box = document.getElementById('preview-box');
    box.innerText = 'جاري المعالجة...';
    try {
        const res = await fetch('http://localhost:8000/chat', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({message: desc})
        });
        const data = await res.json();
        if(data.reply) box.innerText = data.reply;
        else box.innerText = data.detail || 'خطأ غير متوقع';
    } catch (e) {
        box.innerText = 'فشل الاتصال بالخادم';
    }
}

function downloadApp() {
    const content = document.getElementById('preview-box').innerText;
    const blob = new Blob([content], {type: 'text/plain'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'app_preview.txt';
    a.click();
}
